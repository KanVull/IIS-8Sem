﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Threads
{
    class Program
    {
        /// <summary>
        /// Результат выполнения задачи
        /// </summary>
        public struct TaskResult
        {
            //Порядковый номер задачи
            public Int64 TaskNumber;
            //Статус выполнения:
            // 0 - выполняется
            // 1 - выполнена, пароль не найден
            // 2 - выполнена, пароль найден
            public int TaskStatus;
            //Найденный пароль
            public string Password;
        }

        /// <summary>
        /// Класс "Задача"
        /// </summary>
        public class CheckTask
        {
            //Результат выполненая задачи
            public TaskResult Result;
            //Порядковый номер задачи
            private Int64 taskNumber;
            //Номер начальной комбинации для генерации паролей
            private Int64 fromPass;
            //Количество паролей в списке проверки
            private int passCount;
            //Длина пароля
            private int passLength;
            //Хэш корректного пароля
            private string passHash;
            //Алфавит символов
            private string alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            //Список паролей для проверки
            private string[] passList;

            //Конструктор
            public CheckTask(Int64 TaskNumber, Int64 FromPass, int PassCount, int PassLength, string PassHash)
            {
                this.taskNumber = TaskNumber;
                this.fromPass = FromPass;
                this.passCount = PassCount;
                this.passLength = PassLength;
                this.passHash = PassHash;

                this.Result = new TaskResult();
                this.Result.TaskNumber = this.taskNumber;
                this.Result.TaskStatus = 0;
                this.Result.Password = String.Empty;
            }

            //Метод генерации списка паролей для проверки
            private void GetPassList()
            {
                int alphabetLength = this.alphabet.Length;
                Int64 lastPass = Convert.ToInt64(Math.Pow(alphabetLength, this.passLength)) - 1;
                Int64 toPass = this.fromPass + this.passCount > lastPass ? lastPass : this.fromPass + this.passCount;
                this.passList = new string[toPass - this.fromPass + 1];
                StringBuilder sb = new StringBuilder();
                for (Int64 i = this.fromPass; i <= toPass; i++)
                {
                    Int64 c = i;
                    Int64 ci = 0;
                    sb.Clear();
                    for (int j = 0; j < this.passLength; j++)
                    {
                        ci = Convert.ToInt32(c / Convert.ToInt64(Math.Pow(alphabetLength, this.passLength - j - 1)));
                        c = c % Convert.ToInt64(Math.Pow(alphabetLength, this.passLength - j - 1));
                        sb.Append(this.alphabet[Convert.ToInt32(ci)]);
                    }
                    this.passList[i - this.fromPass] = sb.ToString();
                }
            }

            public static string GetHash(string s)
            {
                MD5 md5 = MD5.Create();
                byte[] b = md5.ComputeHash(System.Text.Encoding.ASCII.GetBytes(s));
                string result = System.Text.Encoding.ASCII.GetString(b, 0, b.Length);
                md5.Clear();
                md5.Dispose();
                return result;
            }

            //Метод генерации списка и проверки паролей
            private Task<string> Compute()
            {
                return Task.Run(() =>
                {
                    this.GetPassList();

                    string result = "";
                    foreach(string s in this.passList)
                    {
                        if (GetHash(s) == this.passHash)
                        {
                            result = s;
                            break;
                        }
                    }
                    return result;
                });
            }
                
            //Асинхронный метод вызова метода проверки паролей
            public async Task RunTask()
            {
                //Вызов метода проверки паролей
                var r = Compute();
                //Ожидание результата работы метода проверки паролей
                this.Result.Password = await r;
                //Установка статуса задачи после проверки паролей
                this.Result.TaskStatus = this.Result.Password == "" ? 1 : 2;
            }  
        }    

        static void Main(string[] args)
        {
            //Тестовый пароль
            string password = "zsad";
            //Длина пароля
            int passLength = password.Length;
            //Хэш пароля
            string passHash = CheckTask.GetHash(password);
            //Количество символов в алфавите пароля (латинские строчные и прописные буквы)
            int alphabetLength = 52;
            //Номер начальной комбинации для генерации списка паролей
            Int64 fromPass = 0;
            //Количество паролей в каждом списке для проверки
            int passCount = 100000;
            //Номер последней комбинации с учетом размера алфавита и длины пароля
            Int64 lastPass = Convert.ToInt64(Math.Pow(alphabetLength, passLength)) - 1;
            //Количество параллельно запускаемых задач подбора пароля
            int taskCount = Environment.ProcessorCount;
            //Номер текущей задачи подбора пароля
            Int64 taskNumber = 0;
            //Список активных задач подбора пароля
            List<CheckTask> taskList = new List<CheckTask>();
            //Флаг "Пароль найден"
            bool passFound = false;
            //Найденный пароль
            string calculatedPassword = "";

            //Время начала работы
            DateTime beginTime = DateTime.Now;
            //Цикл, пока пароль не подобран
            while (!passFound && (fromPass < lastPass || taskList.Count > 0))
            {
                //Добавление задач
                if (fromPass < lastPass)
                    for (int i = taskList.Count; i < taskCount; i++)
                    {
                        taskNumber++;
                        taskList.Add(new CheckTask(taskNumber, fromPass, passCount, passLength, passHash));
                        fromPass = fromPass + passCount > lastPass ? lastPass : fromPass + passCount;
                        taskList[taskList.Count - 1].RunTask();
                    }

                //Удаление завершенных задач, не нашедших пароль
                for (int i = taskList.Count - 1; i >= 0; i--)
                {
                    if (taskList[i].Result.TaskStatus == 1)
                    {
                        Console.Write("Task {0}: password not found\n", taskList[i].Result.TaskNumber);
                        taskList.RemoveAt(i);
                    }
                }

                //Удаление завершенных задач, нашедших пароль
                for (int i = taskList.Count - 1; i >= 0; i--)
                {
                    if (taskList[i].Result.TaskStatus == 2)
                    {
                        calculatedPassword = taskList[i].Result.Password;
                        passFound = true;
                        Console.Write("Task {0}: PASSWORD FOUND - {1}\n", taskList[i].Result.TaskNumber, taskList[i].Result.Password);
                        taskList.RemoveAt(i);
                    }
                }
            }
            //Время окончания работы
            DateTime endTime = DateTime.Now;
            //Время затраченное на подбор пароля
            TimeSpan timeSpan = endTime.Subtract(beginTime);

            //Очистка списка задач подбора пароля
            for (int i = taskList.Count - 1; i >= 0; i--)
                taskList.RemoveAt(i);

            Console.Write("\nPASSWORD IS \"{0}\"\n", calculatedPassword);
            Console.Write("Start time: {0}\nEnd time:   {1}\nTime spent: {2} seconds\n", beginTime.ToString(), endTime.ToString(), timeSpan.TotalSeconds.ToString());

            Console.Write("Press Enter for continue...");
            Console.Read();
        }
    }
}
